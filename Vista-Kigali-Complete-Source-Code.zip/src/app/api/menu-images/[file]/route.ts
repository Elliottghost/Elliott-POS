import { readFile } from "node:fs/promises";
import path from "node:path";
import { MENU_UPLOAD_DIR } from "@/lib/uploads";

const CONTENT_TYPES: Record<string, string> = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
};

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ file: string }> },
) {
  const { file } = await params;
  const extension = file.split(".").pop()?.toLowerCase() ?? "";

  if (!/^[a-z0-9-]+\.[a-z0-9]+$/i.test(file) || !CONTENT_TYPES[extension]) {
    return new Response("Not found", { status: 404 });
  }

  try {
    const bytes = await readFile(path.join(MENU_UPLOAD_DIR, path.basename(file)));
    return new Response(new Uint8Array(bytes), {
      headers: {
        "Content-Type": CONTENT_TYPES[extension],
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
