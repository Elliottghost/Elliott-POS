"use client";

import { useEffect, useState } from "react";
import { Suspense } from "next/react";
import Link from "next/link";
import { useSearchParams, usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import { format } from "@/lib/format";

const BRANCHES = [
  {
    id: "kimironko",
    code: "KIM",
    name: "Kimironko — Ku Isangano",
    slug: "kimironko",
    phone: "+250 788 123 456",
    address: "Kimironko Sector, Kigali",
    isActive: true,
  },
  {
    id: "rond-point",
    code: "RDP",
    name: "Rond-Point — Kuri Azam",
    slug: "rond-point",
    phone: "+250 788 789 012",
    address: "Rond-Point, Kigali",
    isActive: true,
  },
];

export default function HomePage() {
  const [selectedBranch, setSelectedBranch] = useState<typeof BRANCHES[0] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for branch in localStorage or URL
    const stored = localStorage.getItem("vista_branch");
    if (stored) {
      const branch = BRANCHES.find((b) => b.id === stored);
      if (branch) setSelectedBranch(branch);
    }
    setLoading(false);
  }, []);

  const router = useRouter();

  const selectBranch = (branch: typeof BRANCHES[0]) => {
    setSelectedBranch(branch);
    localStorage.setItem("vista_branch", branch.id);
    router.push(`/menu?branch=${branch.id}`);
  };

  if (loading || !selectedBranch) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-ember/5 to-sand/3 p-8">
        <div className="text-center">
          <div className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-ember/40 bg-ember/15 mb-6">
            <span className="font-display text-3xl text-ember">V</span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-4">
            Vista Kigali
          </h1>
          <p className="text-[16px] text-muted mb-8">
            Bar · Resto · Accommodation
          </p>
          {BRANCHES.map((branch) => (
            <Button
              key={branch.id}
              onClick={() => selectBranch(branch)}
              className="mx-2 mb-4 w-full sm:w-auto"
            >
              {branch.name}
            </Button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-sand to-ember/5 min-h-screen">
      <nav className="border-b border-line/50 bg-white/90 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <Link href="/">
            <span className="font-display text-2xl font-bold text-ember">Vista Kigali</span>
          </Link>
          <div className="hidden md:flex items-center gap-4">
            <Link href="/menu" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              Menu
            </Link>
            <Link href="/about" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              About
            </Link>
            <Link href="/reservations" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              Reservations
            </Link>
            <Link href="/order-online" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              Order Online
            </Link>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="text-[10px] py-1 px-2 rounded bg-ember/10 text-ember">
              {selectedBranch.code}
            </Badge>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <header className="mb-8">
          <h1 className="font-display text-5xl md:text-6xl font-bold tracking-tight mb-2">
            {selectedBranch.name}
          </h1>
          <p className="text-[16px] text-muted">
            {selectedBranch.address}
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Restaurant Section */}
          <Card className="group hover:shadow-xl transition-shadow">
            <div className="p-6 flex flex-col sm:flex-row items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-ember/10 flex items-center justify-center flex-shrink-0">
                <span className="font-display text-3xl text-ember">🍽️</div>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-display text-xl font-bold mb-1">Restaurant</h3>
                <p className="text-[14px] text-muted mb-2">
                  Fine dining experience with authentic Rwandan and international cuisine
                </p>
                <Button
                  asChild
                  href="/menu?branch=${selectedBranch.id}"
                  className="text-[12px] font-medium text-ember hover:text-cream transition flex items-center gap-1.5"
                >
                  View Menu
                  <svg
                    className="h-3 w-3"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </Button>
                <svg
                  className="h-3 w-3"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </Button>
              <span
                className="text-[12px] text-muted opacity-70 flex-shrink-0"
              >
                {selectedBranch.reservationsToday || 0} reservation{s}
              </span>
            </div>
          </Card>

          {/* Bar Section */}
          <Card className="group hover:shadow-xl transition-shadow">
            <div className="p-6 flex flex-col sm:flex-row items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-ember/10 flex items-center justify-center flex-shrink-0">
                <span className="font-display text-3xl text-ember">🍸</div>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-display text-xl font-bold mb-1">Bar & Drinks</h3>
                <p className="text-[14px] text-muted mb-2">
                  Premium cocktails, wines, and spirits in a sophisticated setting
                </p>
                <Button
                  asChild
                  href="/bar?branch=${selectedBranch.id}"
                  className="text-[12px] font-medium text-ember hover:text-cream transition flex items-center gap-1.5"
                >
                  View Drinks
                  <svg
                    className="h-3 w-3"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M3 3v18h18V3H3zm6 6v4h4V9H9zm6 6v4h4v-4h-4zM9 17H5v2h4v-2zm6-8c-3.31 0-6 2.69-6 6s2.69 6 6 6s6-2.69-6-6z" />
                  </svg>
                </Button>
                <svg
                  className="h-3 w-3"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M3 3v18h18V3H3zm6 6v4h4V9H9zm6 6v4h4v-4h-4zM9 17H5v2h4v-2zm6-8c-3.31 0-6 2.69-6 6s2.69 6 6 6s6-2.69-6-6z" />
                </svg>
              </Button>
              <span
                className="text-[12px] text-muted opacity-70 flex-shrink-0"
              >
                {selectedBranch.reservationsToday || 0} reservation{s}
              </span>
            </div>
          </Card>

          {/* Accommodation Section */}
          <Card className="group hover:shadow-xl transition-shadow">
            <div className="p-6 flex flex-col sm:flex-row items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-ember/10 flex items-center justify-center flex-shrink-0">
                <span className="font-display text-3xl text-ember">🏨</div>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-display text-xl font-bold mb-1">Accommodation</h3>
                <p className="text-[14px] text-muted mb-2">
                  Luxury rooms and suites with city views
                </p>
                <Button
                  asChild
                  href="/accommodation?branch=${selectedBranch.id}"
                  className="text-[12px] font-medium text-ember hover:text-cream transition flex items-center gap-1.5"
                >
                  View Rooms
                  <svg
                    className="h-3 w-3"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M8 2v4h8V2H8zm7 11.93c-.66-1.37-2.23-1.37-2.89 0L3.26 22.5c-.44.76-.01 1.7.74 1.7h14.12c.75 0 1.13-.94.73-1.7l-1.55-2.87zm-9.24-5.38c-.38-.66-.38-1.5.01-2.15l1.55-2.87.01.00c.39.7.97 1.18 1.66 1.28l2.28.38.01-.00c.69-.1 1.33-.47 1.65-1.17l1.38-2.51.01-.00c.38-.7.01-1.5-.01-2.15L9 14.53 5.18 8.3c-.38-.66-.38-1.5.01-2.15l1.55-2.87.01.00c.39.7.97 1.18 1.66 1.28l2.28.38.01-.00c.69-.1 1.33-.47 1.65-1.17l1.38-2.51.01-.00c.38-.7.01-1.5-.01-2.15zM9 17H5v2h4v-2zm6-8c-3.31 0-6 2.69-6 6s2.69 6 6 6s6-2.69-6-6z" />
                  </svg>
                </Button>
              </div>
              <span
                className="text-[12px] text-muted opacity-70 flex-shrink-0"
              >
                {selectedBranch.reservationsToday || 0} reservation{s}
              </span>
            </div>
          </Card>
        </div>

        <div className="mt-12 pt-8 border-t border-line/50">
          <p className="text-[12px] uppercase tracking-[0.2em] text-muted">
            © 2026 Vista Kigali Bar - Resto & Accommodation. All rights reserved.
          </p>
        </div>
      </main>
    </div>
  );
}