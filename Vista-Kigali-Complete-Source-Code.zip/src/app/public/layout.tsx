import "./globals.css";
import { StartTransition } from "react";

export const metadata = {
  title: "Vista Kigali - Bar, Restaurant & Accommodation",
  description: "Premier hospitality destination in Kigali - Fine dining, drinks, and accommodation",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-display antialiased bg-cream text-ink">
        <StartTransition>{children}</StartTransition>
      </body>
    </html>
  );
}