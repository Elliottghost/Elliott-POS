"use client";

import { useEffect, useState } from "react";
import { Suspense } from "next/react";
import Link from "next/link";
import { useSearchParams, usePathname, useRouter } from "next/navigation";
import { useToast } from "@/components/ui/use-toast";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button, ButtonLink } from "@/components/ui/button";
import { Table, TableHeader, TableRow, TableCell, TableBody } from "@/components/ui/table";
import { formatCurrency } from "@/lib/format";
import { useDebounce } from "@/lib/hooks";
import { listMenuCategories, listMenuItems, getMenuItem } from "@/services/menu";
import { listBranches, branchScope, hasPermission } from "@/lib/auth/access";
import { getSetting } from "@/services/settings";
import { useIsMounted } from "@/lib/hooks";

export default function CustomerMenuPage() {
  const [searchParams] = useSearchParams();
  const router = useRouter();
  const [toast] = useToast();
  const [isMounted] = useIsMounted();

  const branchId = searchParams.get("branch") || "";
  const query = searchParams.get("q") || "";
  const categoryId = searchParams.get("category") || "";
  const state = searchParams.get("state") || "all";

  const [branches, setBranches] = useState([]);
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      try {
        // Load branches for selector
        const allBranches = await listBranches(undefined, { includeInactive: false });
        setBranches(allBranches);

        // Load categories
        const allCategories = await listMenuCategories({ includeInactive: false });
        setCategories(allCategories);

        // Load items based on filters
        const items = await listMenuItems({
          includeInactive: false,
          categoryId: categoryId || undefined,
          search: query.trim() || undefined,
          featuredOnly: state === "featured",
        });
        setItems(items);
        setLoading(false);
      } catch (err) {
        console.error("Failed to load menu:", err);
        setError("Failed to load menu. Please try again.");
        setLoading(false);
      }
    }

    load();
  }, [branchId, categoryId, query, state, isMounted]);

  // Update branch when selected
  useEffect(() => {
    if (branchId) {
      localStorage.setItem("vista_branch", branchId);
      router.push(`?branch=${branchId}&q=${encodeURIComponent(query)}&category=${categoryId}&state=${state}`);
    }
  }, [branchId, query, categoryId, state, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-8">
        <div className="prose prose-invert max-w-none">
          <p>Loading menu…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen p-8">
        <Card className="max-w-md mx-auto bg-red/5 border-red/20">
          <div className="p-6">
            <h3 className="font-display text-xl font-bold text-red mb-2">Error</h3>
            <p className="text-muted">{error}</p>
            <ButtonLink href="/">Back to homepage</ButtonLink>
          </div>
        </Card>
      </div>
    );
  }

  const visibleItems =
    state === "hidden"
      ? items.filter((item) => !item.isActive)
      : state === "active"
        ? items.filter((item) => item.isActive)
        : items;

  // Format branch display
  const branchOptions = branches.map((branch) => ({
    value: branch.id,
    label: branch.code,
  }));

  // Find selected branch
  const selectedBranch = branches.find((b) => b.id === branchId) || branches[0];

  return (
    <div className="min-h-screen bg-gradient-to-b from-sand to-ember/5 min-h-screen">
      <nav className="border-b border-line/50 bg-white/90 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="font-display text-xl font-bold text-ember">Vista Kigali</span>
          </Link>
          <div className="hidden md:flex items-center gap-4">
            <Link href="/" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              Home
            </Link>
            <Link href="/menu?branch=" + (selectedBranch?.id || "" ) className="text-[12px] font-semibold text-ink hover:text-ember transition">
              Menu
            </Link>
            <Link href="/about" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              About
            </Link>
            <Link href="/reservations" className="text-[12px] font-semibold text-ink hover:text-ember transition">
              Reservations
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <select
              onChange={(e) => {
                const selected = branches.find((b) => b.id === e.target.value);
                if (selected) {
                  setBranches(prev => prev.map(b => b.id === e.target.value ? { ...b, isSelected: true } : b.id === selectedBranch?.id ? { ...b, isSelected: false } : b));
                  router.push(`?branch=${e.target.value}&q=${encodeURIComponent(query)}&category=${categoryId}&state=${state}`);
                }
              }}
              className="rounded-lg border border-line px-3 py-2 text-[12px] font-medium text-ink focus:outline-none focus:ring-2 focus:ring-ember/30"
            >
              <option value="">All branches</option>
              {branches.map((branch) => (
                <option
                  key={branch.id}
                  value={branch.id}
                  selected={branch.id === branchId}
                >
                  {branch.code}
                </option>
              ))}
            </select>
            <span className="text-[11px] text-muted opacity-70">
              {selectedBranch?.name || ""}
            </span>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="font-display text-4xl md:text-5xl font-bold tracking-tight mb-2">
            Food Menu
          </h1>
          <p className="text-[16px] text-muted">
            Vista Kigali {selectedBranch?.code || ""} — {selectedBranch?.name || ""}
          </p>
        </div>

        {/* Filter Section */}
        <Card className="mb-6 p-4 sm:p-6">
          <form className="grid grid-cols-1 sm:grid-cols-[auto_1fr_auto_auto] gap-3 sm:items-end sm:gap-4" onSubmit={(e) => e.preventDefault()}>
            <div>
              <label className="field-label text-[11px] uppercase tracking-[0.1em] text-muted mb-1">
                Search menu
              </label>
              <input
                type="text"
                placeholder="Dish, drink, or category"
                value={query}
                onChange={(e) => {
                  const q = e.target.value;
                  router.push(`?branch=${branchId}&q=${encodeURIComponent(q)}&category=${categoryId}&state=${state}`);
                }}
                className="field-input flex-1 rounded-lg border border-line px-3 py-2"
              />
            </div>

            <div>
              <label className="field-label text-[11px] uppercase tracking-[0.1em] text-muted mb-1">
                Category
              </label>
              <select
                onChange={(e) => {
                  router.push(`?branch=${branchId}&q=${encodeURIComponent(query)}&category=${e.target.value}&state=${state}`);
                }}
                className="field-input rounded-lg border border-line px-3 py-2"
              >
                <option value="">All categories</option>
                {categories.map((category) => (
                  <option
                    key={category.id}
                    value={category.id}
                    selected={categoryId === category.id}
                  >
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2">
              <Button type="submit" className="flex-1">
                Filter
              </Button>
              <ButtonLink
                href={`/menu?branch=${branchId}`}
                variant="ghost"
                size="sm"
              >
                Clear
              </ButtonLink>
            </div>
          </form>
        </Card>

        {/* Menu Items Grid or Table */}
        {!selectedBranch
          ? (
            <div className="mb-8">
              <Alert
                tone="error"
                description="Please select a branch to view the menu."
              />
            </div>
          )
          : visibleItems.length === 0
            ? (
              <div className="mb-8 text-center py-12">
                <p className="font-display text-lg text-ink">
                  {query ? `No items matching " ${query}"` : "The menu is empty"}
                </p>
                <p className="mx-auto mt-1 max-w-sm text-[13px] leading-relaxed text-muted">
                  This branch currently has no menu items. Please check another branch or contact us.
                </p>
              </div>
            )
            : (
              <Card className="overflow-hidden">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-6 py-3 sm:px-8">
                  <div>
                    <h2 className="text-lg leading-tight">
                      {visibleItems.length} dish{visibleItems.length === 1 ? "" : "s"}
                    </h2>
                    <p className="text-[11px] text-muted">
                      Across {categories.length} category{categories.length === 1 ? "y" : "ies"}
                    </p>
                  </div>
                  {selectedBranch?.code ? (
                    <p className="text-[11px] uppercase tracking-[0.14em] text-muted">
                      {selectedBranch.code} pricing
                    </p>
                  ) : null}
                </div>

                <div className="hidden overflow-x-auto lg:block">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableCell className="w-48">Item</TableCell>
                        <TableCell className="text-muted w-32">Category</TableCell>
                        <TableCell className="text-muted w-24">Prep</TableCell>
                        <TableCell className="text-right w-28">Price</TableCell>
                        <TableCell className="text-right w-32">Branch</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {visibleItems.map((item) => (
                        <TableRow key={item.id} className="border-b border-line/50 hover:bg-ember/5 transition">
                          <TableCell className="font-medium text-ink">
                            <div className="flex items-center gap-3">
                              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line bg-sand/50">
                                {item.imagePath ? (
                                  <img
                                    src={item.imagePath}
                                    alt=""
                                    className="h-full w-full object-cover"
                                  />
                                ) : (
                                  <span className="text-[9px] uppercase tracking-wide text-muted">
                                    {item.name.slice(0, 2)}
                                  </span>
                                )}
                              </span>
                              <span className="min-w-0">
                                <span className="font-medium text-ink">
                                  {item.name}
                                </span>
                                {item.isFeatured ? (
                                  <Badge tone="ember">Featured</Badge>
                                ) : null}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted">{item.categoryName}</TableCell>
                          <TableCell className="text-muted">
                            {item.prepMinutes ? `${item.prepMinutes} min` : "—"}
                            <span className="block text-[10px]">
                              {STATION_LABELS[item.station] ?? item.station}
                            </span>
                          </TableCell>
                          <TableCell className="text-right font-medium tabular-nums">
                            {formatCurrency(item.price, selectedBranch?.currency || "RWF")}
                          </TableCell>
                          <TableCell className="text-right">
                            {selectedBranch?.code}
                          </TableCell>
                          <TableCell>
                            <Badge
                              tone={item.isActive ? "success" : "neutral"}
                            >
                              {item.isActive ? "Available" : "Sold out"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Mobile list view */}
                <ul className="divide-y divide-line/70 lg:hidden">
                  {visibleItems.map((item) => (
                    <li key={item.id} className="px-4 py-3">
                      <div className="flex items-start gap-3">
                        <span className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-line bg-sand/50">
                          {item.imagePath ? (
                            <img
                              src={item.imagePath}
                              alt=""
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <span className="text-[9px] uppercase tracking-wide text-muted">
                              {item.name.slice(0, 2)}
                            </span>
                          )}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="text-[13.5px] font-medium leading-snug text-ink">
                                {item.name}
                              </p>
                              <p className="text-[11px] text-muted">
                                {item.categoryName}
                                {item.prepMinutes ? ` · ${item.prepMinutes} min` : ""}
                              </p>
                            </div>
                            <p className="shrink-0 text-[13px] font-semibold tabular-nums">
                              {formatCurrency(item.price, selectedBranch?.currency || "RWF")}
                            </p>
                          </div>
                          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                            {item.isFeatured ? <Badge tone="ember">Featured</Badge> : null}
                            {!item.isActive ? <Badge tone="neutral">Hidden</Badge> : null}
                          </div>
                        </div>
                      </div>
                      {selectedBranch?.code ? (
                        <div className="mt-2 flex flex-wrap items-center gap-1.5 border-t border-line/60 pt-2">
                          <div>
                            {selectedBranch.code} · {item.isActive ? "on sale" : "sold out"}
                          </div>
                        </div>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </Card>
            )
        }

        {/* Empty state with CTAs */}
        {visibleItems.length === 0 && (
          <div className="mt-8 p-8 text-center bg-white/5 rounded-2xl">
            <h3 className="font-display text-xl font-bold mb-2">No items found</h3>
            <p className="text-muted mb-6">
              Try adjusting your search or selecting a different category.
            </p>
            <div className="flex gap-3 flex-wrap justify-center">
              <ButtonLink href={`/menu?branch=${branchId}`} variant="primary">
                View All Items
              </ButtonLink>
              <ButtonLink href="/" variant="secondary">Back Home</ButtonLink>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Station labels for display
const STATION_LABELS: Record<string, string> = {
  kitchen: "Kitchen",
  bar: "Bar",
  pastry: "Pastry",
};